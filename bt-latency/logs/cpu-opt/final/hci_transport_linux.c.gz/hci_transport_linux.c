/*
 * Copyright (C) 2025 BlueKitchen GmbH
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 * 4. Any redistribution, use, or modification is done solely for
 *    personal benefit and not for any commercial purpose or for
 *    monetary gain.
 *
 * THIS SOFTWARE IS PROVIDED BY BLUEKITCHEN GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL BLUEKITCHEN
 * GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Please inquire about commercial licensing options at 
 * contact@bluekitchen-gmbh.com
 *
 */

#define BTSTACK_FILE__ "hci_transport_linux.c"

#include "hci_transport_linux.h"

#include "btstack_bool.h"
#include "btstack_config.h"
#include "btstack_debug.h"
#include "btstack_run_loop.h"
#include "hci_transport.h"
#include "hci.h"

#include <err.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

// assert pre-buffer for packet type is available
#if !defined(HCI_OUTGOING_PRE_BUFFER_SIZE) || (HCI_OUTGOING_PRE_BUFFER_SIZE == 0)
#error HCI_OUTGOING_PRE_BUFFER_SIZE not defined. Please update hci.h
#endif


// hci packet handler
static void (*hci_transport_linux_packet_handler)(uint8_t packet_type, uint8_t *packet, uint16_t size) = NULL;

// data source for integration with BTstack Runloop
static btstack_data_source_t hci_transport_linux_data_source;

// incoming packet buffer
static uint8_t hci_packet_with_pre_buffer[HCI_INCOMING_PRE_BUFFER_SIZE + HCI_INCOMING_PACKET_BUFFER_SIZE + 1]; // packet type + max(acl header + acl payload, event header + event data)
static uint8_t * hci_packet = &hci_packet_with_pre_buffer[HCI_INCOMING_PRE_BUFFER_SIZE];

#define S31_HCI_BATCH_PACKETS 8
#define S31_HCI_BATCH_RECORD_SIZE (2 + HCI_INCOMING_PACKET_BUFFER_SIZE + 1)
static uint8_t s31_hci_batch[S31_HCI_BATCH_PACKETS * S31_HCI_BATCH_RECORD_SIZE];

// linux hci socket
static int hci_socket = -1;

static uint8_t * hci_pending_write;
static uint32_t hci_pending_write_size;
static int hci_can_send;
/* Private batch ABI: marker, then LE16 length + copied H4 records. */
static unsigned s31_tx_batch_limit;
static unsigned s31_tx_frames;
static unsigned s31_tx_size = 1;
static int s31_tx_waiting_completion;
static uint8_t s31_tx_buffer[1 + 8 * (2 + HCI_OUTGOING_PACKET_BUFFER_SIZE + 1)];

static btstack_context_callback_registration_t hci_packet_sent_registration;

static const hci_transport_config_linux_t * hci_transport_config_linux;

static void hci_transport_linux_emit_packet_sent(void * context) {
    UNUSED(context);
    static const uint8_t packet_sent_event[] = { HCI_EVENT_TRANSPORT_PACKET_SENT, 0 };

    hci_can_send = 1;
    hci_transport_linux_packet_handler(HCI_EVENT_PACKET,
                                       (uint8_t *) packet_sent_event,
                                       sizeof(packet_sent_event));
}

static void hci_transport_linux_schedule_packet_sent(void) {
    hci_packet_sent_registration.callback = &hci_transport_linux_emit_packet_sent;
    hci_packet_sent_registration.context = NULL;
    btstack_run_loop_execute_on_main_thread(&hci_packet_sent_registration);
}

/* Called at a POSIX loop boundary, after local callbacks have filled the
 * batch. Never acknowledge the last full-buffer packet until space exists. */
void s31_hci_flush_tx_batch(void) {
    if (!s31_tx_batch_limit || s31_tx_size == 1) return;
    ssize_t n = write(hci_socket, s31_tx_buffer, s31_tx_size);
    if (n < 0) {
        if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
            perror("S31 batch write");
        btstack_run_loop_enable_data_source_callbacks(&hci_transport_linux_data_source,
                                                       DATA_SOURCE_CALLBACK_WRITE);
        return;
    }
    btstack_assert(n > 1 && (unsigned)n <= s31_tx_size);
    unsigned pos = 1, done = 0;
    while (pos < (unsigned)n) {
        pos += 2 + s31_tx_buffer[pos] + ((unsigned)s31_tx_buffer[pos+1] << 8);
        done++;
    }
    btstack_assert(pos == (unsigned)n && done <= s31_tx_frames);
    memmove(s31_tx_buffer + 1, s31_tx_buffer + n, s31_tx_size - n);
    s31_tx_size -= n - 1;
    s31_tx_frames -= done;
    if (s31_tx_size == 1)
        btstack_run_loop_disable_data_source_callbacks(&hci_transport_linux_data_source,
                                                        DATA_SOURCE_CALLBACK_WRITE);
    else
        btstack_run_loop_enable_data_source_callbacks(&hci_transport_linux_data_source,
                                                       DATA_SOURCE_CALLBACK_WRITE);
    if (s31_tx_waiting_completion) {
        s31_tx_waiting_completion = 0;
        hci_transport_linux_schedule_packet_sent();
    }
}

static void hci_transport_linux_process_write(btstack_data_source_t * ds) {
    if (s31_tx_batch_limit) {
        s31_hci_flush_tx_batch();
        return;
    }

    ssize_t bytes_written;

    btstack_assert(hci_pending_write != NULL);
    bytes_written = write(hci_socket, hci_pending_write, hci_pending_write_size);
    if (bytes_written < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) return;
    if (bytes_written < 0) {
        perror("Failed to retry HCI packet");
        return;
    }
    btstack_assert((uint32_t) bytes_written == hci_pending_write_size);
    hci_pending_write = NULL;
    hci_pending_write_size = 0;
    btstack_run_loop_disable_data_source_callbacks(ds, DATA_SOURCE_CALLBACK_WRITE);
    hci_transport_linux_schedule_packet_sent();
}

static void hci_transport_linux_process_read(btstack_data_source_t * ds) {
    UNUSED(ds);
    int packets;
    size_t offset = 0;

    int bytes_read = read(hci_socket, s31_hci_batch, sizeof(s31_hci_batch));
    if (bytes_read < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            return;
        }
        perror("Failed to read HCI packet batch");
        return;
    }
    if (bytes_read == 0) {
        return;
    }

    for (packets = 0; packets < S31_HCI_BATCH_PACKETS && offset < (size_t) bytes_read; packets++) {
        uint16_t frame_size;
        if ((size_t) bytes_read - offset < 2) {
            log_error("Truncated S31 HCI batch header");
            return;
        }
        frame_size = s31_hci_batch[offset] | (((uint16_t) s31_hci_batch[offset + 1]) << 8);
        offset += 2;
        if (frame_size == 0 || frame_size > HCI_INCOMING_PACKET_BUFFER_SIZE + 1 ||
            frame_size > (size_t) bytes_read - offset) {
            log_error("Invalid S31 HCI batch record size %u", frame_size);
            return;
        }
        memcpy(hci_packet, &s31_hci_batch[offset], frame_size);
        offset += frame_size;
        hci_transport_linux_packet_handler(hci_packet[0], &hci_packet[1],
                                           frame_size - 1);
    }
}

static void hci_transport_linux_process(btstack_data_source_t *ds, btstack_data_source_callback_type_t callback_type) {
    switch (callback_type){
        case DATA_SOURCE_CALLBACK_READ:
            hci_transport_linux_process_read(ds);
            break;
        case DATA_SOURCE_CALLBACK_WRITE:
            hci_transport_linux_process_write(ds);
            break;
        default:
            break;
    }
}

static void hci_transport_linux_init (const void *transport_config){
    btstack_assert(transport_config != NULL);
    hci_transport_config_linux = (const hci_transport_config_linux_t *) transport_config;
    btstack_assert(hci_transport_config_linux->type == HCI_TRANSPORT_CONFIG_LINUX);
    log_info("Using device id %u", hci_transport_config_linux->device_id);
}

static int hci_transport_linux_open(void) {
    const char * direct_device = getenv("S31_HCI_DEVICE");
    if (direct_device == NULL || direct_device[0] == '\0') {
        fprintf(stderr, "S31_HCI_DEVICE is not set\n");
        return -1;
    }
    hci_socket = open(direct_device, O_RDWR | O_CLOEXEC | O_NONBLOCK);
    if (hci_socket < 0) {
        perror("Failed to open direct HCI device");
        return -1;
    }
    log_info("Using direct HCI device %s", direct_device);

    // set up data_source
    btstack_run_loop_set_data_source_fd(&hci_transport_linux_data_source, hci_socket);
    btstack_run_loop_set_data_source_handler(&hci_transport_linux_data_source, &hci_transport_linux_process);
    btstack_run_loop_add_data_source(&hci_transport_linux_data_source);
    btstack_run_loop_enable_data_source_callbacks(&hci_transport_linux_data_source, DATA_SOURCE_CALLBACK_READ);

    const char *batch = getenv("S31_BTSTACK_TX_BATCH");
    s31_tx_batch_limit = batch ? (unsigned)atoi(batch) : 0;
    if (s31_tx_batch_limit > 8) s31_tx_batch_limit = 0;
    if (s31_tx_batch_limit) {
        /* Private direct-HCI ABI. Legacy drivers safely use single writes. */
        uint32_t caps = 0;
        if (ioctl(hci_socket, _IOR('S', 0x31, uint32_t), &caps) < 0 ||
            caps < s31_tx_batch_limit) {
            fprintf(stderr, "S31 TX batch disabled: driver ABI unavailable\n");
            s31_tx_batch_limit = 0;
        }
    }
    s31_tx_frames = 0;
    s31_tx_size = 1;
    s31_tx_buffer[0] = 0xff;
    s31_tx_waiting_completion = 0;
    fprintf(stderr, "S31 TX batch: %u\n", s31_tx_batch_limit);
    hci_pending_write = NULL;
    hci_pending_write_size = 0;
    hci_can_send = 1;
    return 0;
}

static int hci_transport_linux_close(void){
    btstack_run_loop_remove_data_source(&hci_transport_linux_data_source);
    if (hci_socket >= 0) {
        close(hci_socket);
        hci_socket = -1;
    }
    return 0;
}

static void hci_transport_linux_register_packet_handler(void (*handler)(uint8_t packet_type, uint8_t *packet, uint16_t size)){
    hci_transport_linux_packet_handler = handler;
}

static int hci_transport_linux_can_send_packet_now(uint8_t packet_type) {
    UNUSED(packet_type);
    return hci_can_send;
}

static int hci_transport_linux_send_packet(uint8_t packet_type, uint8_t * packet, int size) {
    // store packet type before actual data and increase size
    uint8_t * buffer = &packet[-1];
    uint32_t  buffer_size = size + 1;
    buffer[0] = packet_type;

    btstack_assert(hci_can_send != 0);
    hci_can_send = 0;
    if (s31_tx_batch_limit) {
        btstack_assert(s31_tx_frames < s31_tx_batch_limit);
        btstack_assert(s31_tx_size + 2 + buffer_size <= sizeof(s31_tx_buffer));
        s31_tx_buffer[s31_tx_size++] = buffer_size & 0xff;
        s31_tx_buffer[s31_tx_size++] = buffer_size >> 8;
        memcpy(s31_tx_buffer + s31_tx_size, buffer, buffer_size);
        s31_tx_size += buffer_size;
        s31_tx_frames++;
        if (s31_tx_frames == s31_tx_batch_limit)
            s31_tx_waiting_completion = 1;
        else
            hci_transport_linux_schedule_packet_sent();
        return 0;
    }
    if (write(hci_socket, buffer, buffer_size) < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            hci_pending_write = buffer;
            hci_pending_write_size = buffer_size;
            btstack_run_loop_enable_data_source_callbacks(&hci_transport_linux_data_source,
                                                           DATA_SOURCE_CALLBACK_WRITE);
            return 0;
        }
        perror("Failed to send HCI packet");
        hci_can_send = 1;
        return -1;
    }
    hci_transport_linux_schedule_packet_sent();
    return 0;
}

static const hci_transport_t hci_transport_linux = {
    .name = "ESP32-S31 direct H4",
    .init = &hci_transport_linux_init,
    .open = &hci_transport_linux_open,
    .close = &hci_transport_linux_close,
    .register_packet_handler = &hci_transport_linux_register_packet_handler,
    .can_send_packet_now = &hci_transport_linux_can_send_packet_now,
    .send_packet = &hci_transport_linux_send_packet
};

const hci_transport_t * hci_transport_linux_instance(void) {
    return &hci_transport_linux;
}
