from pathlib import Path
import subprocess,json,re
r=Path('/home/grieferpig/esp32-s31-linux');d=Path(__file__).resolve().parent
dest=d/'extension-hil';dest.mkdir()
def board(where,phase,cmd,timeout=30):
 (where/(phase+'-command.txt')).write_text(cmd+'\n')
 x=subprocess.run(['python3',str(r/'bt-latency/board_command.py'),cmd,str(timeout)],capture_output=True)
 (where/(phase+'.raw')).write_bytes(x.stdout+x.stderr);assert x.returncode==0
 return x.stdout
reset=['/home/grieferpig/.espressif/python_env/idf6.2_py3.13_env/bin/esptool','--chip','esp32s31','--port','/dev/ttyUSB0','--baud','115200','--no-stub','read-mac']
(dest/'reset-command.json').write_text(json.dumps(reset,indent=2))
x=subprocess.run(reset,capture_output=True);(dest/'reset.raw').write_bytes(x.stdout+x.stderr);assert x.returncode==0
subprocess.run(['python3',str(r/'bt-latency/native_monitor.py'),str(dest/'boot.raw'),'30'],stdout=subprocess.DEVNULL,check=True)
x=subprocess.run(['python3',str(r/'bt-latency/board_console.py'),'root','3'],capture_output=True);(dest/'login.raw').write_bytes(x.stdout+x.stderr)
quiet='stty -echo; exec /bin/sh +i'
(dest/'quiet-command.txt').write_text(quiet+'\n')
x=subprocess.run(['python3',str(r/'bt-latency/board_console.py'),quiet,'2'],capture_output=True)
(dest/'quiet.raw').write_bytes(x.stdout+x.stderr);assert x.returncode==0
board(dest,'knob-check','ls /sys/module/esp32s31_ext/parameters; cat /sys/module/esp32s31_ext/parameters/lazy_user')
knobs=board(dest,'default-policy','cat /sys/module/esp32s31_ext/parameters/lazy_user')
assert re.search(rb'^Y\r?$',knobs,re.M),'Lazy policy not the default'
binary=d.parent/'lazy_signal_test';data=binary.read_bytes()
import base64,hashlib
encoded=base64.b64encode(data).decode()
commands=[": > /tmp/lazy-signal-test.b64"]+["printf '%s' '"+encoded[i:i+700]+"' >> /tmp/lazy-signal-test.b64" for i in range(0,len(encoded),700)]
commands+=["base64 -d /tmp/lazy-signal-test.b64 > /tmp/lazy-signal-test; chmod 755 /tmp/lazy-signal-test; sha256sum /tmp/lazy-signal-test"]
(dest/'policy-upload-commands.json').write_text(json.dumps(commands,indent=2))
for index,cmd in enumerate(commands):out=board(dest,'policy-upload-'+str(index),cmd)
assert hashlib.sha256(data).hexdigest().encode() in out
board(dest,'policy-tests','echo 1 > /sys/module/esp32s31_ext/parameters/diagnostics; timeout -s KILL 90 /tmp/lazy-signal-test --cpu0 > /tmp/ext-test.txt 2>&1; rc=$?; timeout -s KILL 90 /tmp/lazy-signal-test >> /tmp/ext-test.txt 2>&1; rc2=$?; echo 0 > /sys/module/esp32s31_ext/parameters/diagnostics; echo CPU0_RC=$rc SIGNAL_RC=$rc2',200)
policy=dest/'policy';policy.mkdir()
subprocess.run(['python3',str(d/'pull_ext_test.py'),str(policy)],check=True)
text=(policy/'ext-test.txt').read_text()
assert 'CPU0 HWLoop disabled before first use, first-use activation PASS' in text,text
assert 'unused/signal/first-use/exec policy PASS' in text,text
print('Initial-off on CPU0/CPU1, unused calls, signal return and exec reset PASS',flush=True)

outputs=[]
for lazy in (0,1):
 out=dest/('lazy' if lazy else 'eager');out.mkdir()
 board(out,'run',f'echo {lazy} > /sys/module/esp32s31_ext/parameters/lazy_user; echo 1 > /sys/module/esp32s31_ext/parameters/diagnostics; timeout -s KILL 180 /usr/sbin/s31-ext-test > /tmp/ext-test.txt 2>&1; rc=$?; echo 0 > /sys/module/esp32s31_ext/parameters/diagnostics; echo TEST_RC=$rc; cat /sys/module/esp32s31_ext/parameters/stats',200)
 subprocess.run(['python3',str(d/'pull_ext_test.py'),str(out)],check=True)
 text=(out/'ext-test.txt').read_text();outputs.append(text)
 assert 'S31 FPU/HWLoop/PIE context tests: PASS' in text or 'S31 FPU/HWLoop/PIE instruction and context tests: PASS' in text,text[-1500:]
 print('lazy',lazy,'context PASS',flush=True)
# Context and supported instruction assertions must be the same, not just the final marker.
assert outputs[0]==outputs[1], 'Eager/lazy instruction results differ'
board(dest,'disable','echo 0 > /sys/module/esp32s31_ext/parameters/lazy_user; echo 0 > /sys/module/esp32s31_ext/parameters/diagnostics')
print('Eager/lazy real instruction + fork/yield/signal results identical',flush=True)
