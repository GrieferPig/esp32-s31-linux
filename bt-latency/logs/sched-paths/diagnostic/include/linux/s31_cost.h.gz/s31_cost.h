/* SPDX-License-Identifier: GPL-2.0 */
/* Temporary scheduler-aware S31 cost diagnostic, not a production interface. */
#ifndef _LINUX_S31_COST_H
#define _LINUX_S31_COST_H
#include <linux/types.h>
struct task_struct;
enum s31_cost_cat {
 S31_COST_OUTSIDE, S31_COST_PAYLOAD, S31_COST_INTEGRATION,
 S31_COST_GATE, S31_COST_WAIT, S31_COST_WAKE, S31_COST_SYNC,
 S31_COST_QUEUE, S31_COST_SCHED, S31_COST_READ, S31_COST_WRITE,
 S31_COST_SELECT, S31_COST_TIME, S31_COST_SYSCALL_OTHER,
 S31_COST_IRQ, S31_COST_SOFTIRQ, S31_COST_IDLE, S31_COST_CATS
};
enum s31_cost_event {
 S31_EV_SWITCH, S31_EV_WORK, S31_EV_PASS, S31_EV_QUEUE,
 S31_EV_GATE_ENTER, S31_EV_GATE_LEAVE, S31_EV_GATE_SUSPEND,
 S31_EV_GATE_RESUME, S31_EV_SYNC_WAIT, S31_EV_SYNC_WAKE,
 S31_EV_DEFERRED_ISR, S31_EV_DIRECT_ISR, S31_EV_IRQ,
 S31_EV_SOFTIRQ, S31_EV_EVENTS
};
u32 s31_cost_enter(u32 cat);
void s31_cost_leave(u32 old);
void s31_cost_tag_radio(u32 base);
void s31_cost_event(u32 event);
void s31_cost_switch(struct task_struct *next);
void s31_cost_irq(bool enter);
void s31_cost_softirq(bool enter);
u32 s31_cost_syscall(long nr);
static inline void s31_cost_cleanup(u32 *old) { s31_cost_leave(*old); }
#define S31_COST_SCOPE(cat) u32 s31_cost_saved __attribute__((cleanup(s31_cost_cleanup))) = s31_cost_enter(cat)
#endif
