// SPDX-License-Identifier: GPL-2.0
/* On-CPU state accounting: context switches stop charging sleeping tasks.
 * No PC sampling. Clock/trap/profiler boundary overhead is included; this is
 * occupancy timing of annotated paths, not instruction-cycle accounting. */
#include <linux/s31_cost.h>
#include <linux/sched.h>
#include <linux/sched/idle.h>
#include <linux/ktime.h>
#include <linux/irqflags.h>
#include <linux/percpu.h>
#include <linux/cpu.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/export.h>
#include <linux/string.h>

#define IRQ_TOKEN BIT(31)
#define SOFT_TOKEN BIT(30)
#define ACTORS 3
struct s31_cost_cpu {
 u64 ns[ACTORS][S31_COST_CATS];
 u32 entries[ACTORS][S31_COST_CATS];
 u32 events[S31_EV_EVENTS];
 u64 start, end, last;
 u32 actor, cat, irq_depth, soft_depth, irq_cat, soft_cat;
 u32 irq_stack[8];
 u32 clock_errors, state_errors;
 bool active;
};
static DEFINE_PER_CPU(struct s31_cost_cpu, s31_cost_data);
static bool s31_cost_enabled;
static DEFINE_MUTEX(s31_cost_control);
static const char *const cat_names[S31_COST_CATS] = {
 "outside", "radio_payload", "radio_integration", "gate", "sync_wait",
 "sync_wake", "sync_critical", "radio_queue", "scheduler", "read", "write",
 "select_poll", "time", "other_syscall", "hardirq", "softirq", "idle"
};
static const char *const actor_names[ACTORS] = {"other", "radio", "btstack"};
static const char *const event_names[S31_EV_EVENTS] = {
 "context_switch", "worker_call", "blob_pass", "radio_queue",
 "gate_enter", "gate_leave", "gate_suspend", "gate_resume",
 "sync_wait", "sync_wake", "deferred_isr", "direct_isr", "hardirq", "softirq"
};
static void cost_state(struct s31_cost_cpu *p, struct task_struct *task)
{
 p->actor = min_t(u32, task->s31_cost_actor, ACTORS - 1);
 if (p->irq_depth)
  p->cat = p->irq_cat;
 else if (p->soft_depth)
  p->cat = p->soft_cat;
 else if (task->s31_cost_category)
  p->cat = task->s31_cost_category;
 else if (is_idle_task(task))
  p->cat = S31_COST_IDLE;
 else
  p->cat = task->s31_cost_base;
 if (p->cat >= S31_COST_CATS) {
  p->cat = S31_COST_OUTSIDE;
  p->state_errors++;
 }
}
static void cost_account(struct s31_cost_cpu *p, u64 now)
{
 if (!p->active) return;
 if (now < p->last) p->clock_errors++;
 else p->ns[p->actor][p->cat] += now - p->last;
 p->last = now;
}
u32 s31_cost_enter(u32 cat)
{
 struct s31_cost_cpu *p;
 unsigned long flags;
 u32 old;
 local_irq_save(flags);
 p = this_cpu_ptr(&s31_cost_data);
 if (READ_ONCE(s31_cost_enabled))
  cost_account(p, ktime_get_mono_fast_ns());
 if (p->irq_depth) {
  old = p->irq_cat | IRQ_TOKEN;
  p->irq_cat = cat;
 } else if (p->soft_depth) {
  old = p->soft_cat | SOFT_TOKEN;
  p->soft_cat = cat;
 } else {
  old = current->s31_cost_category;
  current->s31_cost_category = cat;
 }
 if (READ_ONCE(s31_cost_enabled)) {
  cost_state(p, current);
  if (p->active) p->entries[p->actor][p->cat]++;
 }
 local_irq_restore(flags);
 return old;
}
EXPORT_SYMBOL_GPL(s31_cost_enter);
void s31_cost_leave(u32 old)
{
 struct s31_cost_cpu *p;
 unsigned long flags;
 local_irq_save(flags);
 p = this_cpu_ptr(&s31_cost_data);
 if (READ_ONCE(s31_cost_enabled))
  cost_account(p, ktime_get_mono_fast_ns());
 if (old & IRQ_TOKEN)
  p->irq_cat = old & ~IRQ_TOKEN;
 else if (old & SOFT_TOKEN)
  p->soft_cat = old & ~SOFT_TOKEN;
 else
  current->s31_cost_category = old;
 if (READ_ONCE(s31_cost_enabled))
  cost_state(p, current);
 local_irq_restore(flags);
}
EXPORT_SYMBOL_GPL(s31_cost_leave);
void s31_cost_tag_radio(u32 base)
{
 unsigned long flags;
 struct s31_cost_cpu *p;
 local_irq_save(flags);
 p = this_cpu_ptr(&s31_cost_data);
 if (READ_ONCE(s31_cost_enabled))
  cost_account(p, ktime_get_mono_fast_ns());
 current->s31_cost_actor = 1;
 current->s31_cost_base = base;
 if (READ_ONCE(s31_cost_enabled))
  cost_state(p, current);
 local_irq_restore(flags);
}
EXPORT_SYMBOL_GPL(s31_cost_tag_radio);
void s31_cost_event(u32 event)
{
 unsigned long flags;
 if (!READ_ONCE(s31_cost_enabled) || event >= S31_EV_EVENTS) return;
 local_irq_save(flags);
 if (this_cpu_ptr(&s31_cost_data)->active)
  this_cpu_ptr(&s31_cost_data)->events[event]++;
 local_irq_restore(flags);
}
EXPORT_SYMBOL_GPL(s31_cost_event);
void s31_cost_switch(struct task_struct *next)
{
 struct s31_cost_cpu *p;
 if (!READ_ONCE(s31_cost_enabled)) return;
 /* Caller has IRQs disabled immediately before switch_to. */
 p = this_cpu_ptr(&s31_cost_data);
 cost_account(p, ktime_get_mono_fast_ns());
 p->events[S31_EV_SWITCH]++;
 cost_state(p, next);
}
void s31_cost_irq(bool enter)
{
 struct s31_cost_cpu *p = this_cpu_ptr(&s31_cost_data);
 if (READ_ONCE(s31_cost_enabled))
  cost_account(p, ktime_get_mono_fast_ns());
 if (enter) {
  if (p->irq_depth < ARRAY_SIZE(p->irq_stack))
   p->irq_stack[p->irq_depth] = p->irq_cat;
  else p->state_errors++;
  p->irq_cat = S31_COST_IRQ;
  p->irq_depth++;
  if (READ_ONCE(s31_cost_enabled)) p->events[S31_EV_IRQ]++;
 } else if (p->irq_depth) {
  p->irq_depth--;
  if (p->irq_depth < ARRAY_SIZE(p->irq_stack))
   p->irq_cat = p->irq_stack[p->irq_depth];
 }
 else p->state_errors++;
 cost_state(p, current);
}
void s31_cost_softirq(bool enter)
{
 struct s31_cost_cpu *p;
 unsigned long flags;
 local_irq_save(flags);
 p = this_cpu_ptr(&s31_cost_data);
 if (READ_ONCE(s31_cost_enabled))
  cost_account(p, ktime_get_mono_fast_ns());
 if (enter) {
  if (!p->soft_depth) p->soft_cat = S31_COST_SOFTIRQ;
  p->soft_depth++;
  if (READ_ONCE(s31_cost_enabled)) p->events[S31_EV_SOFTIRQ]++;
 } else if (p->soft_depth) p->soft_depth--;
 else p->state_errors++;
 cost_state(p, current);
 local_irq_restore(flags);
}
u32 s31_cost_syscall(long nr)
{
 u32 cat;
 if (!current->s31_cost_actor && !strncmp(current->comm, "s31-btstack", 11))
  current->s31_cost_actor = 2;
 if (current->s31_cost_actor != 2)
  return current->s31_cost_category;
 /* RV32 asm-generic syscall numbers, including time64 variants. */
 switch (nr) {
 case 63: cat = S31_COST_READ; break;
 case 64: cat = S31_COST_WRITE; break;
 case 72: case 73: case 413: case 414: cat = S31_COST_SELECT; break;
 case 113: case 169: case 403: cat = S31_COST_TIME; break;
 default: cat = S31_COST_SYSCALL_OTHER; break;
 }
 return s31_cost_enter(cat);
}
static void cost_control_cpu(void *reset)
{
 struct s31_cost_cpu *p = this_cpu_ptr(&s31_cost_data);
 u64 now = ktime_get_mono_fast_ns();
 if (reset) {
  /* Keep IRQ nesting: this callback itself runs inside a live IPI. */
  u32 irq = p->irq_depth, soft = p->soft_depth;
  u32 ic = p->irq_cat, sc = p->soft_cat;
  u32 stack[8];
  memcpy(stack,p->irq_stack,sizeof(stack));
  memset(p, 0, sizeof(*p));
  p->irq_depth = irq; p->soft_depth = soft;
  p->irq_cat = ic; p->soft_cat = sc;
  memcpy(p->irq_stack,stack,sizeof(stack));
  p->start = p->last = now;
  p->active = true;
  cost_state(p, current);
 } else {
  cost_account(p, now);
  p->end = now;
  p->active = false;
 }
}
static int cost_show(struct seq_file *m, void *unused)
{
 int cpu, a, c, e, ret = 0;
 mutex_lock(&s31_cost_control);
 if (READ_ONCE(s31_cost_enabled)) { ret = -EBUSY; goto out; }
 for_each_online_cpu(cpu) {
  struct s31_cost_cpu *p = per_cpu_ptr(&s31_cost_data, cpu);
  seq_printf(m, "CPU %d start=%llu end=%llu clock_errors=%u state_errors=%u\n",
   cpu, p->start, p->end, p->clock_errors, p->state_errors);
  for (a = 0; a < ACTORS; a++)
   for (c = 0; c < S31_COST_CATS; c++)
    seq_printf(m, "COST %d %s %s ns=%llu entries=%u\n",
     cpu, actor_names[a], cat_names[c], p->ns[a][c], p->entries[a][c]);
  for (e = 0; e < S31_EV_EVENTS; e++)
   seq_printf(m, "EVENT %d %s count=%u\n",cpu,event_names[e],p->events[e]);
 }
out:
 mutex_unlock(&s31_cost_control);
 return ret;
}
static int cost_open(struct inode *inode, struct file *file)
{ return single_open(file, cost_show, NULL); }
static ssize_t cost_write(struct file *file, const char __user *buf,
 size_t count, loff_t *pos)
{
 char value;
 if (count != 2 || copy_from_user(&value,buf,1) || (value != '0' && value != '1'))
  return -EINVAL;
 mutex_lock(&s31_cost_control);
 if (value == '1') {
  WRITE_ONCE(s31_cost_enabled, false);
  on_each_cpu(cost_control_cpu, (void *)1, 1);
  WRITE_ONCE(s31_cost_enabled, true);
 } else if (READ_ONCE(s31_cost_enabled)) {
  /* Freeze each CPU while it can still account its final interval. */
  on_each_cpu(cost_control_cpu, NULL, 1);
  WRITE_ONCE(s31_cost_enabled, false);
 }
 mutex_unlock(&s31_cost_control);
 return count;
}
static const struct proc_ops cost_ops = {
 .proc_open=cost_open, .proc_read=seq_read, .proc_write=cost_write,
 .proc_lseek=seq_lseek, .proc_release=single_release
};
static int __init cost_init(void)
{ return proc_create("s31_cost",0600,NULL,&cost_ops) ? 0 : -ENOMEM; }
subsys_initcall(cost_init);
